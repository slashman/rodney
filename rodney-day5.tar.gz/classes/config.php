<?
    $mysqlHost = "127.0.0.1:3306";
    $mysqlUser = "root";
    $mysqlPass = "mysql";
    $mysqlData = "rodneydb";
?>