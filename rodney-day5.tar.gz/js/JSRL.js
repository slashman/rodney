var JSRL = new JSRL();

function JSRL(){
	this.player;
	this.dungeon;
	this.dungeonGenerator;
	this.tiles = new Tiles();
	this.websocket = new RWSC();
}