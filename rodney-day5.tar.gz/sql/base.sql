CREATE DATABASE rodneydb DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;

CREATE TABLE rod_session(
    sessionInfo TEXT NOT NULL
)ENGINE=innodb;
